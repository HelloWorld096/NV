import os
import re
from datetime import timedelta
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, make_response, jsonify
from flask_login import (
    login_user, logout_user, login_required, current_user, LoginManager,
)

from config import Config
from extensions import db, login_manager
from models import User, utcnow
from utils.security import get_client_ip, verify_hcaptcha, verify_token
from utils.email import send_verification_email, send_reset_email, VERIFY_SALT, RESET_SALT
from utils.ratelimit import get_or_create_rl_cookie, set_rl_cookie, check_and_log, human_time
from utils.jwt_tokens import create_access_token, create_master_token, decode_token

USERNAME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]{2,19}$")  # 3-20 chars, starts with a letter


def _load_or_create_jwt_keys(app):
    priv_path = app.config["JWT_PRIVATE_KEY_PATH"]
    pub_path = app.config["JWT_PUBLIC_KEY_PATH"]

    if not (os.path.exists(priv_path) and os.path.exists(pub_path)):
        # Convenience for local/dev runs - generates a keypair on first run.
        # In production, run `python generate_keys.py` yourself and keep the
        # private key out of source control instead of relying on this.
        app.logger.warning("JWT keypair not found - generating one now at %s", os.path.dirname(priv_path))
        import generate_keys
        generate_keys.main()

    with open(priv_path, "rb") as f:
        app.config["JWT_PRIVATE_KEY"] = f.read()
    with open(pub_path, "rb") as f:
        app.config["JWT_PUBLIC_KEY"] = f.read()


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    _load_or_create_jwt_keys(app)

    db.init_app(app)
    login_manager.init_app(app)

    with app.app_context():
        db.create_all()

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    # ---------- helpers ----------

    def rl_context():
        """Pull ip/fingerprint/cookie for the current request."""
        ip = get_client_ip(request)
        fingerprint = (request.form.get("fingerprint") or request.args.get("fingerprint") or "").strip()
        cookie_token = get_or_create_rl_cookie(request)
        return ip, fingerprint, cookie_token

    def enforce_rate_limit(action):
        ip, fingerprint, cookie_token = rl_context()
        allowed, retry_after = check_and_log(action, ip, fingerprint, cookie_token)
        return allowed, retry_after, cookie_token

    def attach_rl_cookie(response, cookie_token):
        return set_rl_cookie(response, cookie_token)

    # ---------- cross-server JWT cookies ----------

    def issue_auth_cookies(response, user):
        """Set the short-lived access ('rerolled') and long-lived master JWT cookies."""
        access_token = create_access_token(user)
        master_token = create_master_token(user)
        secure = not app.debug
        response.set_cookie(
            app.config["ACCESS_COOKIE_NAME"], access_token,
            max_age=app.config["ACCESS_TOKEN_TTL_SECONDS"],
            httponly=True, secure=secure, samesite="Lax",
            domain=app.config["JWT_COOKIE_DOMAIN"],
        )
        response.set_cookie(
            app.config["MASTER_COOKIE_NAME"], master_token,
            max_age=app.config["MASTER_TOKEN_TTL_SECONDS"],
            httponly=True, secure=secure, samesite="Strict",
            domain=app.config["JWT_COOKIE_DOMAIN"],
            path="/token/refresh",  # this cookie should only ever be sent to the refresh endpoint
        )
        return response

    def clear_auth_cookies(response):
        response.delete_cookie(app.config["ACCESS_COOKIE_NAME"], domain=app.config["JWT_COOKIE_DOMAIN"])
        response.delete_cookie(app.config["MASTER_COOKIE_NAME"], domain=app.config["JWT_COOKIE_DOMAIN"], path="/token/refresh")
        return response

    def require_internal_key(view):
        """Guards the internal service-to-service API other servers call."""
        @wraps(view)
        def wrapper(*args, **kwargs):
            configured_key = app.config["INTERNAL_API_KEY"]
            if not configured_key:
                app.logger.error("INTERNAL_API_KEY is not set - refusing all internal API calls")
                return jsonify({"error": "internal_api_disabled"}), 503

            provided = request.headers.get("X-Internal-Key", "")
            if not provided or provided != configured_key:
                return jsonify({"error": "unauthorized"}), 401

            allowed_ips = app.config["INTERNAL_API_ALLOWED_IPS"]
            if allowed_ips and get_client_ip(request) not in allowed_ips:
                return jsonify({"error": "forbidden_ip"}), 403

            return view(*args, **kwargs)
        return wrapper

    # ---------- basic pages ----------

    @app.route("/")
    def index():
        if current_user.is_authenticated:
            return redirect(url_for("dashboard"))
        return redirect(url_for("login"))

    @app.route("/dashboard")
    @login_required
    def dashboard():
        return render_template("dashboard.html")

    # ---------- registration ----------

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if current_user.is_authenticated:
            return redirect(url_for("dashboard"))

        ref_code = request.args.get("ref", "").strip().upper()

        if request.method == "GET":
            resp = make_response(render_template(
                "register.html",
                sitekey=app.config["HCAPTCHA_SITEKEY"],
                ref_code=ref_code,
            ))
            _, _, cookie_token = rl_context()
            return attach_rl_cookie(resp, cookie_token)

        username = (request.form.get("username") or "").strip()
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        confirm = request.form.get("confirm_password") or ""
        referral_input = (request.form.get("referral_code") or "").strip().upper()
        hcaptcha_token = request.form.get("h-captcha-response", "")

        def rerender(error):
            flash(error, "error")
            resp = make_response(render_template(
                "register.html",
                sitekey=app.config["HCAPTCHA_SITEKEY"],
                ref_code=referral_input,
                username=username,
            ))
            return attach_rl_cookie(resp, cookie_token)

        allowed, retry_after, cookie_token = enforce_rate_limit("register")
        if not allowed:
            return rerender(f"Too many registration attempts. Try again in {human_time(retry_after)}.")

        if not USERNAME_RE.match(username):
            return rerender("Username must be 3-20 characters, start with a letter, and contain only letters, numbers, or underscores.")
        if not email or "@" not in email:
            return rerender("Please enter a valid email address.")
        if len(password) < 8:
            return rerender("Password must be at least 8 characters long.")
        if password != confirm:
            return rerender("Passwords do not match.")

        ip, _, _ = rl_context()
        if not verify_hcaptcha(hcaptcha_token, ip):
            return rerender("Captcha verification failed. Please try again.")

        if User.query.filter(db.func.lower(User.username) == username.lower()).first():
            return rerender("That username is already taken.")
        if User.query.filter_by(email=email).first():
            return rerender("An account with that email already exists.")

        referred_by = None
        if referral_input:
            referred_by = User.query.filter_by(referral_code=referral_input).first()
            if not referred_by:
                return rerender("That referral code doesn't look right. Leave it blank if you don't have one.")

        user = User(
            username=username,
            email=email,
            referral_code=User.make_unique_referral_code(),
            referred_by_id=referred_by.id if referred_by else None,
        )
        user.set_password(password)
        user.last_verification_sent_at = utcnow()
        db.session.add(user)
        db.session.commit()

        send_verification_email(user)

        resp = make_response(redirect(url_for("verify_sent", email=email)))
        return attach_rl_cookie(resp, cookie_token)

    @app.route("/verify-sent")
    def verify_sent():
        email = request.args.get("email", "")
        return render_template("verify_sent.html", email=email, cooldown=app.config["RESEND_COOLDOWN_SECONDS"])

    @app.route("/verify/<token>")
    def verify_email(token):
        email, error = verify_token(token, VERIFY_SALT, max_age_seconds=1800)
        if error == "expired":
            flash("That verification link has expired. Please request a new one.", "error")
            return redirect(url_for("verify_sent"))
        if error == "invalid":
            flash("That verification link is invalid.", "error")
            return redirect(url_for("login"))

        user = User.query.filter_by(email=email).first()
        if not user:
            flash("Account not found.", "error")
            return redirect(url_for("register"))

        if not user.is_verified:
            user.is_verified = True
            db.session.commit()

        flash("Your email has been verified! You can now log in.", "success")
        return redirect(url_for("login"))

    @app.route("/resend-verification", methods=["GET", "POST"])
    def resend_verification():
        if request.method == "GET":
            return render_template("resend_verification.html", sitekey=app.config["HCAPTCHA_SITEKEY"])

        email = (request.form.get("email") or "").strip().lower()
        hcaptcha_token = request.form.get("h-captcha-response", "")

        allowed, retry_after, cookie_token = enforce_rate_limit("resend_verification")
        resp_kwargs = dict(sitekey=app.config["HCAPTCHA_SITEKEY"])

        if not allowed:
            flash(f"Too many requests. Try again in {human_time(retry_after)}.", "error")
            resp = make_response(render_template("resend_verification.html", **resp_kwargs))
            return attach_rl_cookie(resp, cookie_token)

        ip, _, _ = rl_context()
        if not verify_hcaptcha(hcaptcha_token, ip):
            flash("Captcha verification failed. Please try again.", "error")
            resp = make_response(render_template("resend_verification.html", **resp_kwargs))
            return attach_rl_cookie(resp, cookie_token)

        # Always show the same generic message, whether or not the account exists,
        # to avoid leaking which emails are registered.
        generic_msg = "If that account exists and isn't verified yet, we've sent a new link."

        user = User.query.filter_by(email=email).first()
        if user and not user.is_verified:
            now = utcnow()
            if user.last_verification_sent_at and (now - user.last_verification_sent_at) < timedelta(
                seconds=app.config["RESEND_COOLDOWN_SECONDS"]
            ):
                wait = app.config["RESEND_COOLDOWN_SECONDS"] - int((now - user.last_verification_sent_at).total_seconds())
                flash(f"Please wait {human_time(max(wait,1))} before requesting another email.", "error")
                resp = make_response(render_template("resend_verification.html", **resp_kwargs))
                return attach_rl_cookie(resp, cookie_token)

            user.last_verification_sent_at = now
            db.session.commit()
            send_verification_email(user)

        flash(generic_msg, "success")
        resp = make_response(redirect(url_for("verify_sent", email=email)))
        return attach_rl_cookie(resp, cookie_token)

    # ---------- login / logout ----------

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for("dashboard"))

        if request.method == "GET":
            resp = make_response(render_template("login.html", sitekey=app.config["HCAPTCHA_SITEKEY"]))
            _, _, cookie_token = rl_context()
            return attach_rl_cookie(resp, cookie_token)

        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        hcaptcha_token = request.form.get("h-captcha-response", "")

        allowed, retry_after, cookie_token = enforce_rate_limit("login")

        def rerender(error):
            flash(error, "error")
            resp = make_response(render_template("login.html", sitekey=app.config["HCAPTCHA_SITEKEY"]))
            return attach_rl_cookie(resp, cookie_token)

        if not allowed:
            return rerender(f"Too many login attempts. Try again in {human_time(retry_after)}.")

        ip, _, _ = rl_context()
        if not verify_hcaptcha(hcaptcha_token, ip):
            return rerender("Captcha verification failed. Please try again.")

        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password):
            return rerender("Incorrect email or password.")

        if not user.is_verified:
            return rerender("Please verify your email before logging in.")

        login_user(user, remember=True)
        resp = make_response(redirect(url_for("dashboard")))
        resp = attach_rl_cookie(resp, cookie_token)
        resp = issue_auth_cookies(resp, user)
        return resp

    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        resp = make_response(redirect(url_for("login")))
        return clear_auth_cookies(resp)

    @app.route("/token/refresh", methods=["POST"])
    def token_refresh():
        """
        Called by client-side JS (or another same-site page) to silently mint a new
        access_token ("rerolled") using the long-lived master_token cookie, without
        re-entering a password. Other servers never call this directly - it's only
        reachable via the master_token cookie, which is scoped to this one path.
        """
        master_token = request.cookies.get(app.config["MASTER_COOKIE_NAME"], "")
        claims, error = decode_token(master_token, expected_type="master")
        if error:
            return jsonify({"error": error or "missing_token"}), 401

        user = db.session.get(User, int(claims["sub"]))
        if not user:
            return jsonify({"error": "user_not_found"}), 401

        resp = make_response(jsonify({"status": "refreshed"}))
        return issue_auth_cookies(resp, user)

    # ---------- internal service-to-service API ----------
    # Called by YOUR OTHER SERVERS ONLY (never from a browser). Requires a static
    # shared secret in the X-Internal-Key header - see config.INTERNAL_API_KEY.
    # This exists so other servers can look up a user or double-check a token
    # without you having to hand out raw database credentials to every service.

    @app.route("/internal/verify-token", methods=["POST"])
    @require_internal_key
    def internal_verify_token():
        """
        Optional convenience endpoint: other servers can verify RS256 access tokens
        entirely offline with the public key (see other_server_example/verify.py) and
        don't need this call at all. This exists for services that would rather make
        one call than embed JWT verification themselves, or that want a live check
        against current DB state (e.g. still verified, not deleted).
        """
        token = (request.json or {}).get("token", "")
        claims, error = decode_token(token, expected_type="access")
        if error:
            return jsonify({"valid": False, "error": error}), 401

        user = db.session.get(User, int(claims["sub"]))
        if not user:
            return jsonify({"valid": False, "error": "user_not_found"}), 404

        return jsonify({"valid": True, "claims": claims})

    @app.route("/internal/users/<username>", methods=["GET"])
    @require_internal_key
    def internal_get_user(username):
        """Safe, minimal user lookup for other servers. Never returns password_hash."""
        user = User.query.filter(db.func.lower(User.username) == username.lower()).first()
        if not user:
            return jsonify({"error": "not_found"}), 404
        return jsonify({
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "is_verified": user.is_verified,
            "referral_code": user.referral_code,
            "referred_by": user.referred_by.username if user.referred_by else None,
            "created_at": user.created_at.isoformat(),
        })

    # ---------- forgot / reset password ----------

    @app.route("/forgot-password", methods=["GET", "POST"])
    def forgot_password():
        if request.method == "GET":
            resp = make_response(render_template("forgot_password.html", sitekey=app.config["HCAPTCHA_SITEKEY"]))
            _, _, cookie_token = rl_context()
            return attach_rl_cookie(resp, cookie_token)

        email = (request.form.get("email") or "").strip().lower()
        hcaptcha_token = request.form.get("h-captcha-response", "")

        allowed, retry_after, cookie_token = enforce_rate_limit("forgot_password")

        def rerender(msg, category="error"):
            flash(msg, category)
            resp = make_response(render_template("forgot_password.html", sitekey=app.config["HCAPTCHA_SITEKEY"]))
            return attach_rl_cookie(resp, cookie_token)

        if not allowed:
            return rerender(f"Too many requests. Try again in {human_time(retry_after)}.")

        ip, _, _ = rl_context()
        if not verify_hcaptcha(hcaptcha_token, ip):
            return rerender("Captcha verification failed. Please try again.")

        user = User.query.filter_by(email=email).first()
        if user:
            send_reset_email(user)

        # Generic response regardless of whether the account exists
        return rerender("If that email is registered, a reset link is on its way.", "success")

    @app.route("/reset-password/<token>", methods=["GET", "POST"])
    def reset_password(token):
        email, error = verify_token(token, RESET_SALT, max_age_seconds=1800)
        if error == "expired":
            flash("That reset link has expired. Please request a new one.", "error")
            return redirect(url_for("forgot_password"))
        if error == "invalid":
            flash("That reset link is invalid.", "error")
            return redirect(url_for("forgot_password"))

        user = User.query.filter_by(email=email).first()
        if not user:
            flash("Account not found.", "error")
            return redirect(url_for("forgot_password"))

        if request.method == "GET":
            return render_template("reset_password.html", token=token)

        password = request.form.get("password") or ""
        confirm = request.form.get("confirm_password") or ""

        if len(password) < 8:
            flash("Password must be at least 8 characters long.", "error")
            return render_template("reset_password.html", token=token)
        if password != confirm:
            flash("Passwords do not match.", "error")
            return render_template("reset_password.html", token=token)

        user.set_password(password)
        db.session.commit()
        flash("Your password has been reset. Please log in.", "success")
        return redirect(url_for("login"))

    # ---------- referrals ----------

    @app.route("/refer")
    @login_required
    def refer():
        link = url_for("register", ref=current_user.referral_code, _external=True)
        referred_users = User.query.filter_by(referred_by_id=current_user.id).order_by(User.created_at.desc()).all()
        return render_template("refer.html", link=link, code=current_user.referral_code, referred_users=referred_users)

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
