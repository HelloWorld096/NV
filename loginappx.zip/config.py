import os
from dotenv import load_dotenv

basedir = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(basedir, ".env"))


class Config:
    # --- Core ---
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-me-in-.env")
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", "sqlite:///" + os.path.join(basedir, "app.db")
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # --- Site ---
    SITE_NAME = os.environ.get("SITE_NAME", "MyApp")
    # Used to build absolute links in emails, e.g. https://yourusername.pythonanywhere.com
    BASE_URL = os.environ.get("BASE_URL", "http://127.0.0.1:5000")

    # --- Resend (email) ---
    RESEND_API_KEY = os.environ.get("RESEND_API_KEY", "")
    MAIL_FROM = os.environ.get("MAIL_FROM", "onboarding@resend.dev")

    # --- hCaptcha ---
    HCAPTCHA_SITEKEY = os.environ.get("HCAPTCHA_SITEKEY", "810839ee-20c4-4846-82da-af6815d0fe3e")
    HCAPTCHA_SECRET = os.environ.get("HCAPTCHA_SECRET", "")  # REQUIRED - get from hcaptcha.com dashboard

    # --- Rate limiting windows ---
    RESEND_COOLDOWN_SECONDS = 90  # 1.5 minutes between resend requests

    # (action, max_attempts, window_seconds)
    RATE_LIMITS = {
        "register": (5, 60 * 60),        # 5 attempts / hour
        "login": (8, 15 * 60),           # 8 attempts / 15 min
        "forgot_password": (4, 30 * 60), # 4 attempts / 30 min
        "resend_verification": (6, 60 * 60),  # 6 attempts / hour (in addition to the 90s cooldown)
    }

    # Cookie used purely as a rate-limit correlation token (NOT the session cookie)
    RL_COOKIE_NAME = "rl_token"
    RL_COOKIE_MAX_AGE = 60 * 60 * 24 * 730  # ~2 years

    # --- Cross-server JWT auth ---
    # RS256 keypair: private key signs (this server only), public key verifies
    # (safe to copy to every other server). Generate with generate_keys.py.
    _KEY_DIR = os.path.join(basedir, "keys")
    JWT_PRIVATE_KEY_PATH = os.environ.get("JWT_PRIVATE_KEY_PATH", os.path.join(_KEY_DIR, "private_key.pem"))
    JWT_PUBLIC_KEY_PATH = os.environ.get("JWT_PUBLIC_KEY_PATH", os.path.join(_KEY_DIR, "public_key.pem"))
    JWT_ISSUER = os.environ.get("JWT_ISSUER", "myapp-auth")

    ACCESS_TOKEN_TTL_SECONDS = int(os.environ.get("ACCESS_TOKEN_TTL_SECONDS", 15 * 60))         # 15 min, "rerolled" token
    MASTER_TOKEN_TTL_SECONDS = int(os.environ.get("MASTER_TOKEN_TTL_SECONDS", 30 * 24 * 60 * 60))  # 30 days, "mastoken"

    # Set this to your shared parent domain (e.g. ".yourdomain.com") so that other
    # servers on subdomains of the SAME registrable domain automatically receive
    # these cookies. Leave blank to scope cookies to just this host.
    JWT_COOKIE_DOMAIN = os.environ.get("JWT_COOKIE_DOMAIN", "") or None
    ACCESS_COOKIE_NAME = "access_token"
    MASTER_COOKIE_NAME = "master_token"

    # --- Internal service-to-service API (for your other servers) ---
    # A static shared secret those servers send in an "X-Internal-Key" header.
    # This is NOT meant to be exposed to browsers/users - server-to-server only.
    INTERNAL_API_KEY = os.environ.get("INTERNAL_API_KEY", "")
    # Optional extra hardening: comma-separated list of allowed source IPs.
    INTERNAL_API_ALLOWED_IPS = [
        ip.strip() for ip in os.environ.get("INTERNAL_API_ALLOWED_IPS", "").split(",") if ip.strip()
    ]
