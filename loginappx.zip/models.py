import secrets
from datetime import datetime, timezone

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from extensions import db


def utcnow():
    # Naive UTC datetime - SQLite has no real timezone-aware storage, and mixing
    # naive/aware datetimes when comparing later raises TypeError, so we stay naive
    # throughout the app for consistency.
    return datetime.now(timezone.utc).replace(tzinfo=None)


def generate_referral_code(length: int = 8) -> str:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no ambiguous chars (0/O, 1/I)
    return "".join(secrets.choice(alphabet) for _ in range(length))


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), unique=True, nullable=False, index=True)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)

    is_verified = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow)

    # Email verification resend cooldown tracking
    last_verification_sent_at = db.Column(db.DateTime, nullable=True)

    # Referral system
    referral_code = db.Column(db.String(16), unique=True, nullable=False)
    referred_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    referred_by = db.relationship("User", remote_side=[id], backref="referrals")

    def set_password(self, raw_password: str):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password: str) -> bool:
        return check_password_hash(self.password_hash, raw_password)

    @staticmethod
    def make_unique_referral_code():
        while True:
            code = generate_referral_code()
            if not User.query.filter_by(referral_code=code).first():
                return code


class RateLimitLog(db.Model):
    """
    Generic log used to enforce: rate-limit when (ip AND fingerprint both match)
    OR (cookie token matches) a prior attempt for the same action within a window.
    """
    __tablename__ = "rate_limit_log"

    id = db.Column(db.Integer, primary_key=True)
    action = db.Column(db.String(50), nullable=False, index=True)
    ip = db.Column(db.String(64), nullable=False, index=True)
    fingerprint = db.Column(db.String(128), nullable=False, index=True)
    cookie_token = db.Column(db.String(64), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=utcnow, index=True)
