-- Run this in the Supabase SQL Editor (or via psql) AFTER your Flask app has
-- run once against this database (so the tables already exist from db.create_all()).
--
-- Architecture this sets up:
--   - The main app (PythonAnywhere) connects as the Supabase project's default
--     `postgres` user (or a dedicated owner role) - full DDL/DML rights, runs
--     migrations, is the only thing that ever writes passwords.
--   - Other servers connect using ONE of the two restricted roles below,
--     each with their own password, and NEVER see password_hash.
--
-- Re-run the GRANT statements (not the CREATE ROLE ones) any time you add new
-- tables via a migration, since Postgres does not retroactively grant access
-- to new objects unless you set up ALTER DEFAULT PRIVILEGES (included below).

-- =====================================================================
-- 1. A safe view of users that never exposes password_hash
-- =====================================================================
create or replace view public.v_users as
select
  id,
  username,
  email,
  is_verified,
  referral_code,
  referred_by_id,
  created_at
from public.users;

-- =====================================================================
-- 2. Read-only role - for servers that only ever need to look things up
-- =====================================================================
create role svc_reader with login password 'CHANGE_ME_READER_PASSWORD';

grant usage on schema public to svc_reader;
grant select on public.v_users to svc_reader;

-- Give read-only servers SELECT on your own app-specific tables here too, e.g.:
-- grant select on public.orders to svc_reader;
-- grant select on public.posts to svc_reader;

-- Do NOT grant this role anything on public.users directly (only the view),
-- and do NOT grant it anything on public.rate_limit_log (internal to the
-- auth app, not useful to other services, and slightly abuse-signal-sensitive).

-- Keep future tables readable automatically (only affects tables the main
-- app's role creates AFTER this is run - re-run per new table owner if that changes):
alter default privileges in schema public grant select on tables to svc_reader;

-- =====================================================================
-- 3. Read-write role - for servers that also need to write their own data
-- =====================================================================
create role svc_writer with login password 'CHANGE_ME_WRITER_PASSWORD';

grant usage on schema public to svc_writer;
grant select on public.v_users to svc_writer;

-- Grant read+write only on the specific tables that server actually owns, e.g.:
-- grant select, insert, update, delete on public.orders to svc_writer;
-- Deliberately NOT granting write access to public.users or public.rate_limit_log
-- here - user records and abuse-tracking should only ever be written by the
-- auth app itself. If a specific other server genuinely needs to update a user
-- field (e.g. a "last_active" column you add later), grant that one column:
-- grant update (last_active_at) on public.users to svc_writer;

alter default privileges in schema public grant select, insert, update on tables to svc_writer;

-- =====================================================================
-- 4. Sanity check queries (run as postgres, not as svc_reader/svc_writer)
-- =====================================================================
-- \du                                  -- list roles
-- select grantee, table_name, privilege_type
--   from information_schema.role_table_grants
--   where grantee in ('svc_reader','svc_writer');
