"""
Self-contained JWT auth for cross-server use.

Two tokens are issued at login:

- access_token ("rerolled token"): short-lived (default 15 min), carries the
  full self-contained profile claims (username, email, referred_by, etc). This
  is the token other servers should check on every request. Being short-lived
  limits the damage if one leaks, and it gets silently re-minted ("rerolled")
  via /token/refresh using the master token.

- master_token ("mastoken" / refresh token): long-lived (default 30 days),
  deliberately carries MINIMAL claims (just user id + a token id). Its only
  job is "prove this browser is still allowed to get a new access token" - it
  is never sent to other servers and is only ever accepted at /token/refresh.

Both are signed with RS256 using a private key that only this auth server
holds. Any server that needs to verify an access_token only needs the PUBLIC
key (see keys/public_key.pem) and can do so completely offline - no network
call back to this server, no DB lookup. See other_server_example/verify.py.
"""
import uuid
from datetime import datetime, timedelta, timezone

import jwt
from flask import current_app


def _now():
    return datetime.now(timezone.utc)


def create_access_token(user) -> str:
    now = _now()
    payload = {
        "token_type": "access",
        "sub": str(user.id),
        "username": user.username,
        "email": user.email,
        "is_verified": user.is_verified,
        "referred_by": user.referred_by.username if user.referred_by else None,
        "referral_code": user.referral_code,
        "jti": uuid.uuid4().hex,
        "iat": now,
        "exp": now + timedelta(seconds=current_app.config["ACCESS_TOKEN_TTL_SECONDS"]),
        "iss": current_app.config["JWT_ISSUER"],
    }
    return jwt.encode(payload, current_app.config["JWT_PRIVATE_KEY"], algorithm="RS256")


def create_master_token(user) -> str:
    now = _now()
    payload = {
        "token_type": "master",
        "sub": str(user.id),
        "jti": uuid.uuid4().hex,
        "iat": now,
        "exp": now + timedelta(seconds=current_app.config["MASTER_TOKEN_TTL_SECONDS"]),
        "iss": current_app.config["JWT_ISSUER"],
    }
    return jwt.encode(payload, current_app.config["JWT_PRIVATE_KEY"], algorithm="RS256")


def decode_token(token: str, expected_type: str | None = None):
    """
    Verifies signature + expiry using the PUBLIC key. Returns (claims, error).
    error is None on success, else a short string reason.
    This is exactly what other servers should do to validate a token in isolation.
    """
    try:
        claims = jwt.decode(
            token,
            current_app.config["JWT_PUBLIC_KEY"],
            algorithms=["RS256"],
            issuer=current_app.config["JWT_ISSUER"],
        )
    except jwt.ExpiredSignatureError:
        return None, "expired"
    except jwt.InvalidTokenError:
        return None, "invalid"

    if expected_type and claims.get("token_type") != expected_type:
        return None, "invalid"

    return claims, None
