import uuid
from datetime import timedelta

from sqlalchemy import and_, or_

from extensions import db
from models import RateLimitLog, utcnow


def get_or_create_rl_cookie(request) -> str:
    """Read the rate-limit correlation cookie, or generate a new token if absent."""
    from flask import current_app
    token = request.cookies.get(current_app.config["RL_COOKIE_NAME"])
    if not token:
        token = uuid.uuid4().hex
    return token


def set_rl_cookie(response, token: str):
    from flask import current_app
    response.set_cookie(
        current_app.config["RL_COOKIE_NAME"],
        token,
        max_age=current_app.config["RL_COOKIE_MAX_AGE"],
        httponly=True,
        samesite="Lax",
        secure=not current_app.debug,
    )
    return response


def check_and_log(action: str, ip: str, fingerprint: str, cookie_token: str):
    """
    Enforces: rate-limited if, within the action's window, a prior attempt exists where
        (ip matches AND fingerprint matches)   OR   (cookie_token matches)

    Returns (allowed: bool, retry_after_seconds: int|None).
    Always logs the current attempt (so repeated hits keep tightening the window),
    UNLESS the action is already blocked, in which case we still log it — it's
    still a signal of retry pressure and keeps the block alive rather than
    letting it expire while someone hammers the endpoint.
    """
    from flask import current_app
    max_attempts, window_seconds = current_app.config["RATE_LIMITS"][action]
    since = utcnow() - timedelta(seconds=window_seconds)

    fingerprint = fingerprint or "unknown"

    matching = RateLimitLog.query.filter(
        RateLimitLog.action == action,
        RateLimitLog.created_at >= since,
    ).filter(
        or_(
            and_(RateLimitLog.ip == ip, RateLimitLog.fingerprint == fingerprint),
            RateLimitLog.cookie_token == cookie_token,
        )
    )

    count = matching.count()
    allowed = count < max_attempts

    # Log this attempt regardless of outcome
    entry = RateLimitLog(action=action, ip=ip, fingerprint=fingerprint, cookie_token=cookie_token)
    db.session.add(entry)
    db.session.commit()

    if allowed:
        return True, None

    oldest = matching.order_by(RateLimitLog.created_at.asc()).first()
    retry_after = window_seconds
    if oldest:
        elapsed = (utcnow() - oldest.created_at).total_seconds()
        retry_after = max(1, int(window_seconds - elapsed))
    return False, retry_after


def human_time(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes} min"
    hours = minutes // 60
    return f"{hours}h {minutes % 60}m"
