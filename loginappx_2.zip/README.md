# Login / Registration App

**Data access note:** this app talks to Supabase over its REST API
(PostgREST, plain HTTPS) via the `supabase` Python package, not a direct
Postgres connection (no SQLAlchemy/psycopg2 anymore). That's a hard
requirement for PythonAnywhere's free tier: PA free accounts can only make
outbound HTTP(S) requests to an allowlist of domains, and can **never** open
a raw TCP socket to anything (which is what a Postgres connection string
needs), no matter what's whitelisted - PA staff have confirmed this
directly. `.supabase.co`/`.supabase.com` are already on PA's free allowlist
because Supabase's REST API is a documented public HTTPS API, so this
approach works on PA free tier where a direct DB connection never would.
See `supabase_client.py` and `models.py`.

Flask app with:
- Email + password registration and login (Flask-Login sessions)
- Email verification via **Resend**, with a resend cooldown (1.5 min)
- Forgot password / reset password via emailed, time-limited tokens
- **hCaptcha** on register, login, forgot-password, and resend forms
- Referral system: every user gets a referral code/link; new signups record who referred them
- Rate limiting that blocks an action when **(IP AND device fingerprint both match)**
  **OR** **(rate-limit cookie matches)** a prior attempt within a time window

## 1. Local setup

```bash
cd loginapp
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

1. Create a free Supabase project at supabase.com if you don't have one.
2. In the Supabase SQL Editor, run `supabase/schema.sql` once — this creates
   the `users` and `rate_limit_log` tables (replaces the old `db.create_all()`).
3. Edit `.env` and fill in:
   - `SECRET_KEY` — any long random string (`python -c "import secrets; print(secrets.token_hex(32))"`)
   - `SUPABASE_URL` / `SUPABASE_SERVICE_ROLE_KEY` — from Project Settings -> Data API /
     API Keys (Legacy tab) in the Supabase dashboard. See `.env.example` for details.
   - `RESEND_API_KEY` — from resend.com. **Rotate/regenerate your key if it was ever pasted
     into a chat, email, or anywhere outside your own secrets manager.**
   - `HCAPTCHA_SECRET` — from your hCaptcha dashboard (the *secret* key, not the site key).
     The site key `810839ee-20c4-4846-82da-af6815d0fe3e` from your message is already the
     default `HCAPTCHA_SITEKEY`, but that alone doesn't verify anything server-side — you
     need the matching secret key too, or verification will always fail closed.
   - `BASE_URL` — the public URL emails will link back to (e.g. your PythonAnywhere domain).

Run it:
```bash
python app.py
```
Visit http://127.0.0.1:5000

## 2. How the rate limiting works

Every sensitive form (register, login, forgot-password, resend-verification) submits:
- The visitor's IP (via `X-Forwarded-For`, since PythonAnywhere sits behind a proxy)
- A device fingerprint computed client-side (`static/js/fingerprint.js`) from canvas +
  navigator/screen signals, hashed with SHA-256
- A long-lived, httponly rate-limit cookie (separate from the login session cookie)

Each attempt is logged to `RateLimitLog`. Before processing a request, the app checks:

```
blocked if EXISTS a prior attempt for this action, within the window, where
    (ip matches AND fingerprint matches)
    OR
    (cookie token matches)
```

This means clearing cookies alone doesn't bypass it (IP+fingerprint still matches), and
spoofing a fingerprint alone doesn't either (cookie still matches), while still allowing
different real users behind the same IP (e.g. office NAT) to register/login normally,
since their fingerprint and cookie will differ.

Per-action limits live in `config.py` under `RATE_LIMITS`. The verification email
resend has an *additional*, separate 90-second-per-account cooldown on top of this,
tracked on the `User.last_verification_sent_at` column.

Note: canvas/device fingerprinting is a heuristic, not a hard identity guarantee — treat
it as an anti-abuse signal, not a security boundary on its own (that's why it's combined
with IP and a cookie rather than relied on alone).

## 3. Deploying to PythonAnywhere

1. **Upload the code.** Easiest: push this folder to a GitHub repo, then in a
   PythonAnywhere Bash console:
   ```bash
   git clone https://github.com/yourusername/yourrepo.git
   cd yourrepo
   pip install --user -r requirements.txt
   ```
   (Or use the Files tab to upload the zip and unzip it there.)

2. **Create a `.env` file** in the same folder as `app.py` (Files tab → New file),
   with the same contents as `.env.example` but with your real secrets. Do **not**
   commit this file to a public repo.

3. **Web tab → Add a new web app** → Manual configuration → your Python version.

4. **Set the virtualenv path** in the Web tab to wherever you installed dependencies
   (or create one explicitly: `mkvirtualenv --python=/usr/bin/python3.x myenv` then
   `pip install -r requirements.txt` inside it, and point the Web tab at it).

5. **Edit the WSGI configuration file** (linked from the Web tab) so it points at this
   app, e.g.:
   ```python
   import sys
   path = '/home/yourusername/yourrepo'
   if path not in sys.path:
       sys.path.insert(0, path)

   from app import app as application
   ```

6. **Static files mapping** (Web tab): map URL `/static/` to
   `/home/yourusername/yourrepo/static/` so `fingerprint.js` loads correctly.

7. Hit **Reload** on the Web tab and visit your PythonAnywhere URL.

### Database note
All storage is in Supabase, accessed over HTTPS via its REST API — see the
data access note at the top of this file for why. There's no local database
file to manage on PythonAnywhere; just make sure `SUPABASE_URL` and
`SUPABASE_SERVICE_ROLE_KEY` are set in `.env` and that you've run
`supabase/schema.sql` once in the Supabase SQL Editor.

### Free-tier ceilings worth checking at 400-500 daily users
Two free-tier limits are more likely to bite than the networking setup:
- **PythonAnywhere free tier's CPU-seconds/day budget** (currently 100
  sec/day) — each request only burns CPU time while actively processing, so
  whether this is enough depends on your actual request volume and per-request
  work; watch the Web tab's CPU usage graph after a few real days of traffic.
- **Supabase free tier's** request volume, bandwidth, and database size limits
  — check the current numbers on supabase.com/pricing, since these change.

### HTTPS / cookies
The rate-limit cookie is set `secure=True` whenever `app.debug` is off (i.e. in
production), so it will only be sent over HTTPS. PythonAnywhere serves your app over
HTTPS by default, so this should just work.

## 4. Cross-server auth: access token, master token, and other servers

Besides the normal Flask-Login session (used by this app's own pages), login also
issues two **RS256-signed JWTs as cookies**, meant for other servers you host to
authenticate the same user:

| Cookie | Lifetime | Purpose |
|---|---|---|
| `access_token` | 15 min (the "rerolled" token) | Self-contained: `username`, `email`, `is_verified`, `referred_by`, `referral_code`, `sub` (user id), `exp`, `jti`. This is what other servers check on every request. |
| `master_token` | 30 days (the "mastoken") | Deliberately minimal claims (just user id + token id). Only ever sent to `/token/refresh`, and only used to mint a new `access_token` — never sent to other servers. |

**Why RS256 instead of one shared secret:** the auth server holds a *private* key
and is the only thing that can sign tokens. Every other server only needs the
*public* key to verify a signature — it physically cannot mint a valid token, even
if that server were compromised. Generate the keypair with:
```bash
python generate_keys.py
```
This writes `keys/private_key.pem` (keep on the auth server only, never commit it)
and `keys/public_key.pem` (copy this — and only this — to your other servers).

**How another server validates a token, completely in isolation** — no network call
back to this app, no DB lookup, works even if this app is down:
```python
# other_server_example/verify.py, ready to copy into another server
claims, error = verify_access_token(request.cookies.get("access_token"))
if error:
    return "unauthorized", 401
# claims["username"], claims["referred_by"], etc. are already right there
```
See `other_server_example/verify.py` for the full, runnable version.

**Cookie sharing across servers:** this only works automatically if your other
servers are subdomains of the same registrable domain (e.g. `app.example.com` and
`api.example.com`). Set `JWT_COOKIE_DOMAIN=.example.com` in `.env` so the browser
sends the cookie to all of them. If your other servers are on genuinely unrelated
domains, cookies won't cross-share by design (that's a browser security boundary,
not a bug) — you'd instead need to pass the access token explicitly, e.g. as a
header after a redirect, or via a small SSO handoff flow.

**Refreshing:** when `access_token` expires, call `POST /token/refresh` (browser
sends `master_token` automatically since it's scoped to that path) to get a new
`access_token` without re-entering a password. Do this proactively from client-side
JS a little before the 15-minute mark, or reactively when another server returns 401.

### Internal service API (for your other servers, not for browsers)

Rather than handing out raw database credentials to every other service — which
increases blast radius if any one of them is compromised, and gives you no
audit trail or ability to rate-limit — `app.py` exposes a small authenticated
internal API instead:

- `GET /internal/users/<username>` — safe, minimal profile lookup (never returns
  the password hash).
- `POST /internal/verify-token` — optional; verifies a token and cross-checks
  current DB state (e.g. still verified). Most services should just use
  `other_server_example/verify.py` directly instead, since it's faster and doesn't
  depend on this server being reachable.

Both require a header `X-Internal-Key: <INTERNAL_API_KEY>` matching the secret in
`.env`. Generate one with:
```bash
python -c "import secrets; print(secrets.token_hex(32))"
```
Optionally also set `INTERNAL_API_ALLOWED_IPS` to a comma-separated allowlist for
defense in depth. Treat `INTERNAL_API_KEY` like a root credential: it's server-to-
server only, never sent to a browser, and should differ from anything a user-facing
client ever holds.

**Note if you're centralizing on Supabase (below):** if one of your other
servers is also on a host that restricts outbound raw TCP (many free tiers
do — check before assuming otherwise), it can query Supabase's REST API
directly the same way this app does, using its own scoped credentials (see
`supabase/other_servers.sql`) instead of calling this Flask app's
`/internal/*` API. But for a simple "look up one user" read, calling
`/internal/users/<username>` on this app is usually less setup: it's a
normal inbound HTTPS request to your own PythonAnywhere domain, which isn't
subject to PA's (or anyone else's) outbound restrictions at all, since it's
the *other* server making an outbound call *to* PA, not the reverse.

## 5b. Centralizing on Supabase: giving other servers restricted access

If several of your other servers should share this Supabase project (rather
than each talking only to this Flask app's `/internal/*` API), the default,
simplest, and most future-proof option is: **have them call this app's
`/internal/*` endpoints** (see section 4 above) rather than talk to Supabase
directly. That's a normal inbound HTTPS request to your PythonAnywhere
domain, it doesn't depend on Supabase's key/JWT internals, and it works
regardless of what network restrictions *those* other servers are under.

If a server genuinely needs direct, multi-row query access to Supabase
instead (e.g. "give me everyone referred by X"), it can talk to Supabase's
REST API the same way this app does — over plain HTTPS, never a raw Postgres
connection — using its own, more restricted credentials:

- **This app (the auth server)** uses the project's `service_role` key (see
  `.env.example` / `supabase_client.py`) — full read/write, bypasses Row
  Level Security entirely. It's the only thing that ever writes
  `password_hash`, and the only thing that should hold this key.
- **`svc_reader` / `svc_writer`** — restricted Postgres roles set up by
  `supabase/other_servers.sql`, for other servers that should only see a
  safe view of users (`v_users`, which excludes `password_hash`) and, for
  `svc_writer`, their own app-specific tables. Un­like the old direct-Postgres
  version of this setup, these roles aren't reachable via a connection
  string — PostgREST assumes a role based on a signed JWT's `role` claim, so
  each server ends up minting or holding a JWT that says "I am svc_reader",
  not a Postgres username/password. Full details and caveats about
  Supabase's ongoing key-system migration are in the SQL file's comments.

To set it up:
1. Run `supabase/schema.sql` once (see section 1 above) — creates the tables
   with Row Level Security enabled and no policies, so only the
   `service_role` key (i.e., this app) can touch them at all by default.
2. If you need the read-only/read-write roles for other servers, additionally
   run `supabase/other_servers.sql`, changing the two placeholder passwords.
3. Whenever you add a new app-specific table those roles need, add the
   matching `GRANT` line and re-run it (the default-privileges lines at the
   bottom of the script cover *future* tables automatically, but only for
   ones created after they're set up).

**How this relates to the JWT auth above:** the two mechanisms answer
different questions and are meant to be used together, not as alternatives —
the Postgres role (if you use one) controls *what a given server is allowed
to do to the database at all*, while the `access_token` JWT tells that
server *which user* is making the current request, so it can apply its own
per-user logic on top of whatever access it already has.

## 5. Referral flow

- Every user gets a unique `referral_code` at signup.
- `/refer` (login required) shows the user's code, a shareable link
  (`/register?ref=CODE`), and a list of people they've referred.
- The register form pre-fills the referral code from `?ref=` and also accepts it typed
  in manually. An invalid code is rejected with a clear error rather than silently
  ignored.

## 6. Security notes / things to double check before going live

- Set a real, random `SECRET_KEY` — this signs both session cookies and email tokens.
- Get a real `HCAPTCHA_SECRET`; without it, hCaptcha verification is coded to **fail
  closed** (reject), not silently pass.
- Consider adding a `robots.txt` / basic logging/alerting on repeated 429s.
- Verification and reset links expire after 30 minutes (`max_age_seconds=1800` in
  `app.py`) — adjust if you want a different window.
- This app doesn't send emails for account enumeration-sensitive actions (forgot
  password, resend verification) without giving away whether the address exists —
  responses there are intentionally generic.
- Usernames are unique and validated (3-20 chars, must start with a letter, letters/
  numbers/underscores only) — checked case-insensitively so `Alice` and `alice`
  can't both register.
- **Never commit** `keys/private_key.pem` or `.env` to a public repo.
  Add them to `.gitignore` if you push this to GitHub.
