"""
Run this once to generate the RSA keypair used to sign and verify JWTs.

    python generate_keys.py

This writes keys/private_key.pem (KEEP SECRET, only the main auth server needs it)
and keys/public_key.pem (safe to copy to every other server that needs to verify
tokens - it can ONLY verify, it cannot mint valid tokens).

Why RS256 instead of a shared HS256 secret:
Since your other servers only need to *validate* tokens, not issue them, giving them
the public key means a compromise of any one of those servers can't be used to forge
a valid token for your whole system. If you used a single shared HS256 secret instead,
any server holding it could mint tokens for any user.
"""
import os
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "keys")


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    private_path = os.path.join(OUT_DIR, "private_key.pem")
    public_path = os.path.join(OUT_DIR, "public_key.pem")

    if os.path.exists(private_path):
        print(f"{private_path} already exists - refusing to overwrite. Delete it first if you really want new keys.")
        return

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    with open(private_path, "wb") as f:
        f.write(
            key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            )
        )
    os.chmod(private_path, 0o600)

    with open(public_path, "wb") as f:
        f.write(
            key.public_key().public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo,
            )
        )

    print(f"Wrote {private_path} (keep this on the auth server only, never commit it)")
    print(f"Wrote {public_path} (copy this to any other server that needs to verify tokens)")


if __name__ == "__main__":
    main()
