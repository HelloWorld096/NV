"""
Data layer for the `users` and `rate_limit_log` tables, backed by Supabase's
REST API (PostgREST) over HTTPS - NOT a direct Postgres/psycopg2 connection.

Why: PythonAnywhere's free tier only ever allows outbound HTTP(S) to
allowlisted domains; it cannot open a raw Postgres socket at all, regardless
of whitelisting. `.supabase.co` / `.supabase.com` ARE on PA's free allowlist,
because Supabase's REST API is a documented public HTTPS API - so REST calls
via `supabase_client.supabase` work fine on PA free, while `psycopg2` never
would have.

This module owns every read/write to these two tables. Nothing else in the
app should import `supabase_client` directly for these tables - go through
the functions here instead, so the query shapes stay in one place.
"""
import re
import secrets
from datetime import datetime, timedelta, timezone

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from supabase_client import supabase

USERS_TABLE = "users"
RATE_LIMIT_TABLE = "rate_limit_log"


def utcnow() -> datetime:
    """Timezone-aware UTC now - the `users`/`rate_limit_log` tables use
    `timestamptz` columns, and PostgREST returns/expects ISO 8601 strings with
    an offset, so we stay timezone-aware throughout (unlike the old SQLite
    naive-datetime version of this file)."""
    return datetime.now(timezone.utc)


def _parse_ts(value):
    """Parse a PostgREST timestamptz string ('...Z' or '...+00:00') into an
    aware datetime. Returns None if value is falsy."""
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat()


def generate_referral_code(length: int = 8) -> str:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no ambiguous chars (0/O, 1/I)
    return "".join(secrets.choice(alphabet) for _ in range(length))


def _escape_ilike(value: str) -> str:
    """Escape %, _, and \\ so an ilike lookup behaves like a case-insensitive
    EXACT match instead of a wildcard pattern (Postgres ILIKE treats `_` as
    'any one character', and usernames here are allowed to contain `_`)."""
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


class User(UserMixin):
    """Thin wrapper around a `users` row. Flask-Login only needs `get_id()`;
    UserMixin supplies is_authenticated/is_active/is_anonymous."""

    def __init__(self, row: dict):
        self.id = row["id"]
        self.username = row["username"]
        self.email = row["email"]
        self.password_hash = row["password_hash"]
        self.is_verified = bool(row["is_verified"])
        self.created_at = _parse_ts(row.get("created_at"))
        self.last_verification_sent_at = _parse_ts(row.get("last_verification_sent_at"))
        self.referral_code = row["referral_code"]
        self.referred_by_id = row.get("referred_by_id")

    def get_id(self):
        # flask-login expects a string
        return str(self.id)

    def set_password(self, raw_password: str):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password: str) -> bool:
        return check_password_hash(self.password_hash, raw_password)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------

def find_by_id(user_id: int):
    res = supabase.table(USERS_TABLE).select("*").eq("id", user_id).limit(1).execute()
    return User(res.data[0]) if res.data else None


def find_by_email(email: str):
    res = supabase.table(USERS_TABLE).select("*").eq("email", email).limit(1).execute()
    return User(res.data[0]) if res.data else None


def find_by_username_ci(username: str):
    """Case-insensitive lookup (mirrors the DB's unique index on lower(username))."""
    res = (
        supabase.table(USERS_TABLE)
        .select("*")
        .ilike("username", _escape_ilike(username))
        .limit(1)
        .execute()
    )
    return User(res.data[0]) if res.data else None


def find_by_referral_code(code: str):
    res = supabase.table(USERS_TABLE).select("*").eq("referral_code", code).limit(1).execute()
    return User(res.data[0]) if res.data else None


def get_username(user_id):
    """Resolve just a username for a given id - used to fill in
    'referred_by' on JWT claims and the internal API without pulling a full
    row (or dealing with self-referencing-FK embed syntax)."""
    if not user_id:
        return None
    res = supabase.table(USERS_TABLE).select("username").eq("id", user_id).limit(1).execute()
    return res.data[0]["username"] if res.data else None


def list_referred_by(user_id):
    res = (
        supabase.table(USERS_TABLE)
        .select("*")
        .eq("referred_by_id", user_id)
        .order("created_at", desc=True)
        .execute()
    )
    return [User(row) for row in res.data]


def make_unique_referral_code() -> str:
    while True:
        code = generate_referral_code()
        if not find_by_referral_code(code):
            return code


# ---------------------------------------------------------------------------
# Writes
# ---------------------------------------------------------------------------

class DuplicateUserError(Exception):
    """Raised when an insert races a unique constraint (username/email/referral_code)."""


def create_user(username: str, email: str, password: str, referral_code: str, referred_by_id=None) -> User:
    payload = {
        "username": username,
        "email": email,
        "password_hash": generate_password_hash(password),
        "is_verified": False,
        "referral_code": referral_code,
        "referred_by_id": referred_by_id,
        "last_verification_sent_at": _iso(utcnow()),
    }
    try:
        res = supabase.table(USERS_TABLE).insert(payload).execute()
    except Exception as exc:  # postgrest.exceptions.APIError on unique-constraint conflicts (HTTP 409)
        if "duplicate key" in str(exc).lower() or "23505" in str(exc):
            raise DuplicateUserError(str(exc)) from exc
        raise
    return User(res.data[0])


def mark_verified(user_id):
    supabase.table(USERS_TABLE).update({"is_verified": True}).eq("id", user_id).execute()


def touch_verification_sent(user_id, when: datetime):
    supabase.table(USERS_TABLE).update({"last_verification_sent_at": _iso(when)}).eq("id", user_id).execute()


def set_password_hash(user_id, new_password: str):
    supabase.table(USERS_TABLE).update({"password_hash": generate_password_hash(new_password)}).eq(
        "id", user_id
    ).execute()


# ---------------------------------------------------------------------------
# Rate limiting (was RateLimitLog SQLAlchemy model)
# ---------------------------------------------------------------------------

# ip/fingerprint/cookie_token are attacker-influenced input that ends up
# interpolated into a PostgREST `or=(...)` filter string, which uses commas
# and parentheses as grammar. None of these three should legitimately contain
# such characters (hex fingerprint, uuid cookie token, dotted/colon IP), so we
# whitelist-validate them and substitute a harmless literal if they don't
# match - this can never itself become a false rate-limit bypass, since a
# munged value just won't match any real row.
_SAFE_TOKEN_RE = re.compile(r"^[A-Za-z0-9:._-]{1,128}$")


def _safe_or_value(value: str) -> str:
    return value if _SAFE_TOKEN_RE.match(value or "") else "__invalid__"


def check_and_log(action: str, ip: str, fingerprint: str, cookie_token: str, max_attempts: int, window_seconds: int):
    """
    Enforces: rate-limited if, within the window, a prior attempt exists where
        (ip matches AND fingerprint matches)   OR   (cookie_token matches)

    Returns (allowed: bool, retry_after_seconds: int|None). Always logs the
    current attempt, same behavior as the original SQLAlchemy version.
    """
    since = utcnow() - timedelta(seconds=window_seconds)
    fingerprint = fingerprint or "unknown"

    safe_ip = _safe_or_value(ip)
    safe_fp = _safe_or_value(fingerprint)
    safe_cookie = _safe_or_value(cookie_token)
    or_filter = f"and(ip.eq.{safe_ip},fingerprint.eq.{safe_fp}),cookie_token.eq.{safe_cookie}"

    matching = (
        supabase.table(RATE_LIMIT_TABLE)
        .select("id,created_at", count="exact")
        .eq("action", action)
        .gte("created_at", _iso(since))
        .or_(or_filter)
        .execute()
    )
    count = matching.count or 0
    allowed = count < max_attempts

    # Log this attempt regardless of outcome (still logged even while blocked,
    # which keeps the block alive rather than letting it expire under retries).
    supabase.table(RATE_LIMIT_TABLE).insert(
        {"action": action, "ip": ip, "fingerprint": fingerprint, "cookie_token": cookie_token}
    ).execute()

    if allowed:
        return True, None

    retry_after = window_seconds
    if matching.data:
        oldest = min(_parse_ts(row["created_at"]) for row in matching.data)
        elapsed = (utcnow() - oldest).total_seconds()
        retry_after = max(1, int(window_seconds - elapsed))
    return False, retry_after
