"""
Drop this into any OTHER server that needs to authenticate your users.

It needs ONLY:
  1. This file (or the verify_access_token function copied into your codebase)
  2. public_key.pem (copy it from the auth server's keys/public_key.pem -
     this is safe to distribute; it can verify tokens but cannot create them)
  3. PyJWT installed (`pip install PyJWT cryptography`)

It talks to NOTHING - no network call to the auth server, no database call.
Signature + expiry + issuer are all checked locally. That's what "isolated
validation" means here: this server can independently decide whether to trust
a request without depending on the auth server being reachable.

Usage in a Flask app on another server:

    from verify import verify_access_token

    @app.route("/whoami")
    def whoami():
        token = request.cookies.get("access_token")  # sent automatically if
                                                       # JWT_COOKIE_DOMAIN covers
                                                       # this server's domain
        claims, error = verify_access_token(token)
        if error:
            return {"error": error}, 401
        return {"username": claims["username"], "referred_by": claims["referred_by"]}
"""
import jwt

ISSUER = "myapp-auth"  # must match config.JWT_ISSUER on the auth server

with open("public_key.pem", "rb") as f:
    PUBLIC_KEY = f.read()


def verify_access_token(token: str):
    """Returns (claims, error). error is None on success."""
    if not token:
        return None, "missing_token"
    try:
        claims = jwt.decode(token, PUBLIC_KEY, algorithms=["RS256"], issuer=ISSUER)
    except jwt.ExpiredSignatureError:
        return None, "expired"
    except jwt.InvalidTokenError:
        return None, "invalid"

    if claims.get("token_type") != "access":
        # Reject master/refresh tokens even if one somehow ended up here -
        # they were never meant to authorize requests directly.
        return None, "wrong_token_type"

    return claims, None
