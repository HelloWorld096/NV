// Lightweight device fingerprint - combines a few stable browser/device signals
// into a SHA-256 hash. Not as strong as a paid fingerprinting service, but enough
// to correlate "same device" for abuse/rate-limiting purposes alongside IP + cookie.
async function computeFingerprint() {
  const components = [];
  try { components.push(navigator.userAgent || ""); } catch (e) {}
  try { components.push(navigator.language || ""); } catch (e) {}
  try { components.push(`${screen.width}x${screen.height}x${screen.colorDepth}`); } catch (e) {}
  try { components.push(Intl.DateTimeFormat().resolvedOptions().timeZone || ""); } catch (e) {}
  try { components.push(String(navigator.hardwareConcurrency || "")); } catch (e) {}
  try { components.push(navigator.platform || ""); } catch (e) {}
  try {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    ctx.textBaseline = "top";
    ctx.font = "14px Arial";
    ctx.fillStyle = "#f60";
    ctx.fillRect(0, 0, 60, 20);
    ctx.fillStyle = "#069";
    ctx.fillText("fp", 2, 2);
    components.push(canvas.toDataURL());
  } catch (e) {}

  const raw = components.join("###");

  try {
    const enc = new TextEncoder().encode(raw);
    const hashBuffer = await crypto.subtle.digest("SHA-256", enc);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  } catch (e) {
    // Fallback: simple non-cryptographic hash if SubtleCrypto is unavailable (e.g. non-HTTPS)
    let hash = 0;
    for (let i = 0; i < raw.length; i++) {
      hash = (hash << 5) - hash + raw.charCodeAt(i);
      hash |= 0;
    }
    return "fallback-" + Math.abs(hash).toString(16);
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  const fp = await computeFingerprint();
  document.querySelectorAll('input[name="fingerprint"]').forEach((el) => {
    el.value = fp;
  });
});
