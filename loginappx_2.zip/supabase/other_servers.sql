-- OPTIONAL. Run in the Supabase SQL Editor if you want OTHER servers to read
-- user data directly via Supabase's REST API, using their own restricted
-- credentials instead of this app's INTERNAL_API_KEY (see README section 4).
--
-- For most setups, just calling this app's `/internal/users/<username>`
-- endpoint (guarded by INTERNAL_API_KEY) is simpler and doesn't depend on
-- anything below - it works over plain HTTPS to your own PythonAnywhere
-- domain, which is a normal INBOUND request to PA, not an outbound one, so
-- none of PA's free-tier egress restrictions apply to whoever is calling you.
-- Use this file only if a server needs to query many rows directly (e.g.
-- "everyone referred by X") rather than one user at a time.

-- =====================================================================
-- 1. A safe view of users that never exposes password_hash
-- =====================================================================
create or replace view public.v_users as
select
  id, username, email, is_verified, referral_code, referred_by_id, created_at
from public.users;

-- =====================================================================
-- 2. Read-only / read-write Postgres roles
-- =====================================================================
create role svc_reader with login password 'CHANGE_ME_READER_PASSWORD' nologin;
-- (nologin: this role is only ever assumed by PostgREST via a signed JWT's
-- "role" claim - see note below - never used for a direct TCP connection.)

grant usage on schema public to svc_reader;
grant select on public.v_users to svc_reader;
alter default privileges in schema public grant select on tables to svc_reader;

create role svc_writer with login password 'CHANGE_ME_WRITER_PASSWORD' nologin;
grant usage on schema public to svc_writer;
grant select on public.v_users to svc_writer;
-- Grant write access only on tables that server actually owns, e.g.:
-- grant select, insert, update, delete on public.orders to svc_writer;
-- Deliberately NOT writable: public.users, public.rate_limit_log - only this
-- Flask app (via its service_role key) should ever write those.
alter default privileges in schema public grant select, insert, update on tables to svc_writer;

-- =====================================================================
-- 3. How another server actually uses svc_reader/svc_writer over REST
-- =====================================================================
-- PostgREST switches to the Postgres role named in a JWT's "role" claim, if
-- that JWT is validly signed with your project's JWT secret (Dashboard ->
-- Project Settings -> API -> JWT Settings - "Legacy JWT Secret"). So instead
-- of a connection string, mint a JWT like:
--   { "role": "svc_reader", "iss": "supabase", "exp": <far future> }
-- signed HS256 with that secret, then call:
--   GET https://<ref>.supabase.co/rest/v1/v_users?username=eq.bob
--   Headers: apikey: <anon key>, Authorization: Bearer <the JWT above>
--
-- Caveat: Supabase is migrating off shared JWT secrets entirely (toward
-- sb_publishable_/sb_secret_ keys and asymmetric signing) through the rest
-- of 2026 - check https://supabase.com/docs/guides/getting-started/api-keys
-- for the current state before relying on this for anything long-lived.
-- The `/internal/*` Flask endpoint doesn't have this dependency at all.
