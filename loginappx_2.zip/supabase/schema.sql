-- Run this ONCE in the Supabase SQL Editor before first deploying the app.
-- This replaces the old `db.create_all()` call, which needed a live
-- SQLAlchemy connection this app no longer has (see README section 4).

-- =====================================================================
-- 1. Tables
-- =====================================================================
create table if not exists public.users (
  id                         bigint generated always as identity primary key,
  username                   varchar(32)  not null,
  email                      varchar(255) not null,
  password_hash              varchar(255) not null,
  is_verified                boolean      not null default false,
  created_at                 timestamptz  not null default now(),
  last_verification_sent_at  timestamptz,
  referral_code               varchar(16)  not null,
  referred_by_id              bigint references public.users(id)
);

-- Case-insensitive uniqueness on username (app also pre-checks this, but the
-- index is the actual guarantee under concurrent signups).
create unique index if not exists users_username_lower_uidx on public.users (lower(username));
create unique index if not exists users_email_uidx on public.users (email);
create unique index if not exists users_referral_code_uidx on public.users (referral_code);
create index if not exists users_referred_by_id_idx on public.users (referred_by_id);

create table if not exists public.rate_limit_log (
  id            bigint generated always as identity primary key,
  action        varchar(50)  not null,
  ip            varchar(64)  not null,
  fingerprint   varchar(128) not null,
  cookie_token  varchar(64)  not null,
  created_at    timestamptz  not null default now()
);

create index if not exists rl_action_created_idx on public.rate_limit_log (action, created_at);
create index if not exists rl_ip_fp_idx on public.rate_limit_log (ip, fingerprint);
create index if not exists rl_cookie_idx on public.rate_limit_log (cookie_token);

-- =====================================================================
-- 2. Row Level Security
-- =====================================================================
-- The Flask app connects with the `service_role` key, which bypasses RLS
-- entirely - so these tables work for the app either way. We enable RLS
-- with ZERO policies anyway, as defense in depth: if the `anon`/`authenticated`
-- keys (safe to expose to browsers) were ever used against these tables
-- directly, they'd be refused rather than exposing password hashes or
-- rate-limit / abuse-tracking data. Nothing other than this trusted server
-- should touch these two tables at all.
alter table public.users enable row level security;
alter table public.rate_limit_log enable row level security;

-- See supabase/other_servers.sql if you want to grant OTHER servers
-- restricted (read-only or scoped read-write) access to a safe view of
-- `users` via their own credentials, instead of sharing service_role.
