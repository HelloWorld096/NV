"""
Supabase REST client for this app.

This talks to `https://<project-ref>.supabase.co/rest/v1/...` over plain
HTTPS - which is why it works on PythonAnywhere's free tier. `.supabase.co`
and `.supabase.com` are on PA's free-account allowlist (Supabase's REST API
is a documented public HTTP API), but PA free tier NEVER allows raw TCP
socket connections (e.g. the Postgres wire protocol psycopg2/SQLAlchemy
would use), no matter what's whitelisted - PA staff have confirmed this
directly ("We allowlist only HTTP(S) connections"). So this app must talk to
Postgres through PostgREST, not through a direct Postgres connection string.

This app is the trusted auth server, so it uses the `service_role` key,
which bypasses Row Level Security entirely and has full read/write on every
table - equivalent to the old setup's `postgres` / owner-role DB user. NEVER
use the service_role key anywhere except this trusted server, and never send
it to a browser. Your OTHER servers should use their own, more restricted
credentials - see supabase/other_servers.sql and the README.
"""
import os

from dotenv import load_dotenv
from supabase import create_client, Client

load_dotenv()

SUPABASE_URL = os.environ.get("SUPABASE_URL", "")
SUPABASE_SERVICE_ROLE_KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")

if not SUPABASE_URL or not SUPABASE_SERVICE_ROLE_KEY:
    raise RuntimeError(
        "SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set in .env.\n"
        "Get both from the Supabase dashboard: Project Settings -> Data API\n"
        "  - SUPABASE_URL is the 'Project URL' (https://<ref>.supabase.co)\n"
        "  - SUPABASE_SERVICE_ROLE_KEY is under 'Project API keys' -> service_role\n"
        "    (NOT the anon/public key - this app needs full access and bypasses RLS)."
    )

supabase: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
