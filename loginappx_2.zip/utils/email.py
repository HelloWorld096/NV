import resend
from flask import current_app

from utils.security import generate_token

VERIFY_SALT = "email-verify"
RESET_SALT = "password-reset"


def _send(to_email: str, subject: str, html: str):
    resend.api_key = current_app.config["RESEND_API_KEY"]
    try:
        resend.Emails.send(
            {
                "from": current_app.config["MAIL_FROM"],
                "to": to_email,
                "subject": subject,
                "html": html,
            }
        )
        return True
    except Exception:
        current_app.logger.exception("Failed to send email via Resend")
        return False


def send_verification_email(user):
    token = generate_token(user.email, VERIFY_SALT)
    link = f"{current_app.config['BASE_URL']}/verify/{token}"
    site = current_app.config["SITE_NAME"]
    html = f"""
    <p>Welcome to {site}!</p>
    <p>Please confirm your email address by clicking the link below:</p>
    <p><a href="{link}">{link}</a></p>
    <p>This link expires in 30 minutes. If you didn't create an account, you can ignore this email.</p>
    """
    return _send(user.email, f"Verify your {site} account", html)


def send_reset_email(user):
    token = generate_token(user.email, RESET_SALT)
    link = f"{current_app.config['BASE_URL']}/reset-password/{token}"
    site = current_app.config["SITE_NAME"]
    html = f"""
    <p>We received a request to reset your {site} password.</p>
    <p><a href="{link}">{link}</a></p>
    <p>This link expires in 30 minutes. If you didn't request this, you can ignore this email.</p>
    """
    return _send(user.email, f"Reset your {site} password", html)
