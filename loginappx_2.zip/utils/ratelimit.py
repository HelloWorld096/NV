import uuid

from models import check_and_log as _check_and_log


def get_or_create_rl_cookie(request) -> str:
    """Read the rate-limit correlation cookie, or generate a new token if absent."""
    from flask import current_app
    token = request.cookies.get(current_app.config["RL_COOKIE_NAME"])
    if not token:
        token = uuid.uuid4().hex
    return token


def set_rl_cookie(response, token: str):
    from flask import current_app
    response.set_cookie(
        current_app.config["RL_COOKIE_NAME"],
        token,
        max_age=current_app.config["RL_COOKIE_MAX_AGE"],
        httponly=True,
        samesite="Lax",
        secure=not current_app.debug,
    )
    return response


def check_and_log(action: str, ip: str, fingerprint: str, cookie_token: str):
    """
    Enforces: rate-limited if, within the action's window, a prior attempt exists where
        (ip matches AND fingerprint matches)   OR   (cookie_token matches)

    Returns (allowed: bool, retry_after_seconds: int|None). The actual query
    now runs over Supabase's REST API (see models.check_and_log) instead of a
    local SQLAlchemy session - see models.py for why.
    """
    from flask import current_app
    max_attempts, window_seconds = current_app.config["RATE_LIMITS"][action]
    return _check_and_log(action, ip, fingerprint, cookie_token, max_attempts, window_seconds)


def human_time(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes} min"
    hours = minutes // 60
    return f"{hours}h {minutes % 60}m"
