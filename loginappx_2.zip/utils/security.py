import requests
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from flask import current_app


def get_client_ip(request) -> str:
    """
    PythonAnywhere (and most PaaS hosts) sit behind a reverse proxy, so the
    real client IP is in X-Forwarded-For. Fall back to remote_addr locally.
    """
    forwarded = request.headers.get("X-Forwarded-For", "")
    if forwarded:
        # X-Forwarded-For can be a comma-separated list; first entry is the client
        return forwarded.split(",")[0].strip()
    return request.remote_addr or "unknown"


def get_serializer(salt: str) -> URLSafeTimedSerializer:
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt=salt)


def generate_token(data: str, salt: str) -> str:
    return get_serializer(salt).dumps(data)


def verify_token(token: str, salt: str, max_age_seconds: int):
    """Returns (data, error). error is None on success, else 'expired' or 'invalid'."""
    try:
        data = get_serializer(salt).loads(token, max_age=max_age_seconds)
        return data, None
    except SignatureExpired:
        return None, "expired"
    except BadSignature:
        return None, "invalid"


def verify_hcaptcha(response_token: str, remote_ip: str) -> bool:
    secret = current_app.config["HCAPTCHA_SECRET"]
    if not secret:
        # Fail safe: if not configured, don't silently accept everything in production.
        current_app.logger.warning("HCAPTCHA_SECRET is not set - captcha verification skipped!")
        return False
    if not response_token:
        return False
    try:
        resp = requests.post(
            "https://hcaptcha.com/siteverify",
            data={
                "secret": secret,
                "response": response_token,
                "remoteip": remote_ip,
            },
            timeout=8,
        )
        result = resp.json()
        return bool(result.get("success"))
    except requests.RequestException:
        current_app.logger.exception("hCaptcha verification request failed")
        return False
