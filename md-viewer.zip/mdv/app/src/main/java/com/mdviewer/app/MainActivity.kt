package com.mdviewer.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.WindowInsetsController
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream

/**
 * Single-screen app: a WebView that shows assets/index.html (the Markdown viewer/editor).
 *
 * Privacy model: the file's text is only ever held in memory. Nothing about the document is
 * written to disk by this app. The web UI keeps only its own settings (theme, font size,
 * indent, wrap) in the WebView's localStorage.
 */
class MainActivity : Activity() {

    private lateinit var web: WebView

    @Volatile private var pendingText: String? = null
    @Volatile private var pendingName: String = "document.md"
    private var pageLoaded = false
    private var saveText = ""

    // ---------------------------------------------------------------- lifecycle

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val night = isNight()
        applyBars(night)

        web = WebView(this)
        web.setBackgroundColor(if (night) 0xFF0D1117.toInt() else Color.WHITE)
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true            // settings live in localStorage
            allowFileAccess = true              // required to load file:///android_asset
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            setSupportZoom(false)
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                // Only our own bundled page may be shown inside the WebView.
                if (url.toString().startsWith("file:///android_asset/")) return false
                // Everything else (links inside a Markdown file) opens in the user's browser/mail app.
                openExternal(url)
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                pageLoaded = true
                if (pendingText != null) pull()
            }
        }

        web.loadUrl("file:///android_asset/index.html")
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    // ---------------------------------------------------------------- opening files

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_VIEW) i.data?.let { loadUri(it) }
    }

    private fun loadUri(uri: Uri) {
        Thread {
            try {
                val name = displayName(uri)
                val bytes = contentResolver.openInputStream(uri)?.use { readLimited(it) }
                    ?: throw IOException("Cannot open stream")
                val text = String(bytes, Charsets.UTF_8).removePrefix("\uFEFF")
                runOnUiThread { deliver(text, name) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Could not open file: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun readLimited(input: InputStream): ByteArray {
        val max = 20 * 1024 * 1024
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > max) throw IOException("File is larger than 20 MB")
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "document.md"
    }

    /** Hand the text to the web page. The page pulls it through the bridge (no big JS strings). */
    private fun deliver(text: String, name: String) {
        pendingText = text
        pendingName = name
        if (pageLoaded) pull()
    }

    private fun pull() {
        web.evaluateJavascript("window.MDV&&MDV.pull()", null)
    }

    // ---------------------------------------------------------------- results (picker / save)

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_OPEN -> loadUri(uri)
            REQ_SAVE -> Thread {
                try {
                    contentResolver.openOutputStream(uri, "wt")?.use {
                        it.write(saveText.toByteArray(Charsets.UTF_8))
                    }
                    runOnUiThread { Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
        } catch (_: Exception) {
            Toast.makeText(this, "No app can open this link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isNight() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** Colour the system bars to match the in-app theme. */
    @Suppress("DEPRECATION")
    private fun applyBars(dark: Boolean) {
        val color = if (dark) 0xFF0D1117.toInt() else Color.WHITE
        window.statusBarColor = color
        window.navigationBarColor = color
        if (Build.VERSION.SDK_INT >= 30) {
            val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(if (dark) 0 else mask, mask)
        } else {
            val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            val flags = window.decorView.systemUiVisibility
            window.decorView.systemUiVisibility = if (dark) flags and light.inv() else flags or light
        }
    }

    // ---------------------------------------------------------------- JS <-> native bridge

    /** Methods here are callable from the page as `AndroidBridge.xxx()` (JS thread, not UI thread). */
    private inner class Bridge {
        @JavascriptInterface fun hasPending(): Boolean = pendingText != null

        @JavascriptInterface fun getName(): String = pendingName

        /** Returns the pending document once, then forgets it. */
        @JavascriptInterface fun getText(): String {
            val t = pendingText ?: ""
            pendingText = null
            return t
        }

        @JavascriptInterface fun copy(text: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("markdown", text))
            }
        }

        /** Opens the system "Save as" dialog; the text is written only where the user chooses. */
        @JavascriptInterface fun save(name: String, text: String) {
            saveText = text
            runOnUiThread {
                @Suppress("DEPRECATION")
                startActivityForResult(
                    Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "text/markdown"
                        putExtra(Intent.EXTRA_TITLE, name)
                    }, REQ_SAVE
                )
            }
        }

        @JavascriptInterface fun pickFile() {
            runOnUiThread {
                @Suppress("DEPRECATION")
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }, REQ_OPEN
                )
            }
        }

        @JavascriptInterface fun setTheme(dark: Boolean) {
            runOnUiThread { applyBars(dark) }
        }
    }

    companion object {
        private const val REQ_OPEN = 1
        private const val REQ_SAVE = 2
    }
}
